import { Injectable } from '@angular/core';
import { ConfigService } from '../config/config.service'
import { HttpClient } from '@angular/common/http';

import { ICheckpoint } from '../models/checkpoint.model'
import { IComponent } from '../models/component.model'
import { ITypes } from '../models/types.model'



@Injectable({
  providedIn: 'root'
})
export class ProductionapiService {

  constructor(public config: ConfigService, public http: HttpClient) { }

  public async getCheckPoints(){
    return new Promise<ICheckpoint[]>((resolve) => {
      this.http.get<ICheckpoint[]>(this.config.serverDomenName+'/checkpoints').subscribe(e=>{
          resolve(e);
        })
      })
    }

    public async getTypes(){
      return new Promise<ITypes[]>((resolve) => {
        this.http.get<ITypes[]>(this.config.serverDomenName+'/types').subscribe(e=>{
            resolve(e);
          })
        })
      }

    public async getComponentsAll(){
    return new Promise<IComponent[]>((resolve) => {
      this.http.get<IComponent[]>(this.config.serverDomenName+'/components').subscribe(e=>{
          resolve(e);
        })
      })
    }
    
    public async getComponent(id:number){
      return new Promise<IComponent[]>((resolve) => {
        this.http.get<IComponent[]>(this.config.serverDomenName+`/components/${id}`).subscribe(e=>{
            resolve(e);
          })
        })
      }
}
