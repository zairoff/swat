export interface ICheckpoint {
    id?:number;
    name?:string;
    status?:string;
    photo?: string
}
