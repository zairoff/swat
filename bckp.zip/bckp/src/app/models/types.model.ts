export interface ITypes {
    id: number,
    name: string
}
